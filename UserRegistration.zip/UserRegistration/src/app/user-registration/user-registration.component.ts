import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, NgForm, Validators, ValidationErrors, AbstractControl } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';

import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
// import { EventEmitter } from 'events';

// Depending on whether rollup is used, moment needs to be imported differently.
// Since Moment.js doesn't have a default export, we normally need to import using the `* as`
// syntax. However, rollup creates a synthetic default module and we thus need to import it using
// the `default as` syntax.
// import moment, { Moment } from 'moment';
// import * as _moment from 'moment';

// const moment = _moment;

// const MY_FORMATS = {
//   parse: {
//     dateInput: 'DD/MM/YYYY',
//   },
//   display: {
//     dateInput: 'DD/MM/YYYY',
//     monthYearLabel: 'MMMM YYYY',
//     dateA11yLabel: 'LL',
//     monthYearA11yLabel: 'MMMM YYYY',
//   },
// };
interface MY_DISPLAY_FORMAT {
  dateInput: string;
  monthYearLabel: string;
  dateA11yLabel: string;
  monthYearA11yLabel: string;
}

interface MY_PARSE_FORMAT {
  dateInput: string;
}

interface MY_FORMAT {
  parse: MY_PARSE_FORMAT;
  display: MY_DISPLAY_FORMAT
}
export class MyFormat {
  value = "dmy";
  // display
  constructor() {

  }
  get display(): MY_DISPLAY_FORMAT {
    let _dsplFMT: MY_DISPLAY_FORMAT = {} as MY_DISPLAY_FORMAT;
    if (this.value == "dmy") {
      _dsplFMT = {
        dateInput: 'DD/MM/YYYY',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
      }
    } else if (this.value == "mdy") {
      _dsplFMT = {
        dateInput: 'MM/DD/YYYY',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
      }
    } else if (this.value == "my") {
      _dsplFMT = {
        dateInput: 'MMM YYYY',
        monthYearLabel: 'MMMM YYYY',
        dateA11yLabel: 'LL',
        monthYearA11yLabel: 'MMMM YYYY',
      }
    }
    return _dsplFMT;
  }
  get parse(): MY_PARSE_FORMAT {
    let _parseFMT: MY_PARSE_FORMAT = {} as MY_PARSE_FORMAT;
    if (this.value == "dmy") {
      _parseFMT = { dateInput: 'DD/MM/YYYY' };
    } else if (this.value == "mdy") {
      _parseFMT = { dateInput: 'MM/DD/YYYY' };
    } else if (this.value == "my") {
      _parseFMT = { dateInput: 'MMM YYYY' };
    }
    return _parseFMT;
  }
}

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useClass: MyFormat },
  ]
})
export class UserRegistrationComponent implements OnInit {
  userForm: FormGroup = {} as FormGroup;
  // matcher = new MyErrorStateMatcher();
  showPassword: boolean = false;
  showPasswordConfirm: boolean = false;
  constructor(private formBuilder: FormBuilder, private http: HttpClient, @Inject(MAT_DATE_FORMATS) public config: MyFormat) { }

  ngOnInit(): void {
    function passwordMatchValidator(): ValidationErrors | null {
      return (c: AbstractControl): { mismatch: boolean } | null => {
        let pswd: string = c.value?.password;
        let cpswd: string = c.value?.passwordConfirm;
        if (pswd === undefined || cpswd === undefined || pswd === cpswd) return null;
        else return { mismatch: true };
      };
    }

    // this.userForm = new FormGroup({
    this.userForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('^[a-z A-Z]+$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-z A-Z]+$')]],
      dob: [''],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}'), passwordMatchValidator]],
      passwordConfirm: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}'), passwordMatchValidator]],
    });
    // }, { validator: this.passwordMatchValidator });
    // this.userForm.setValidators([this.passwordMatchValidator]);
    this.userForm.setValidators([passwordMatchValidator]);
    // this.userForm.updateValueAndValidity({ onlySelf: true });
  }
  onSubmit() {
    let isMismatch = this.userForm.value.password != this.userForm.value.passwordConfirm;

    this.userForm.setErrors(isMismatch ? { miamatch: isMismatch } : null);
    if (this.userForm.valid) {
      //alert('User form is valid!!')
      this.http.post('/api/register', this.userForm.value)
        .subscribe((response) => {
          console.log('repsonse ', response);
        });      
    } else {
      alert('Registration form is not valid!!')
    }
  }
}
